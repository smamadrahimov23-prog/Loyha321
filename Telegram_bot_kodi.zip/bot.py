import asyncio
import html
import logging
import os
import re
import tempfile
import uuid
from pathlib import Path

import yt_dlp
from aiogram import BaseMiddleware, Bot, Dispatcher, F
from aiogram.client.default import DefaultBotProperties
from aiogram.filters import CommandStart
from aiogram.types import (
    CallbackQuery,
    FSInputFile,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)
from shazamio import Shazam

# ================== SOZLAMALAR ==================
BOT_TOKEN = os.getenv("BOT_TOKEN", "8221540234:AAEArcN2GFEnyH3rWTZaD3G5HRVuF6NSauc")
CHANNEL = "@uzbek1ston_news"
CHANNEL_URL = "https://t.me/uzbek1ston_news"
COOKIES_FILE = "cookies.txt"  # ixtiyoriy (Instagram/YouTube uchun)
MAX_SIZE = 49 * 1024 * 1024  # Telegram Bot API limiti ~50MB
# ================================================

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("bot")

URL_RE = re.compile(
    r"(https?://[^\s]*(?:instagram\.com|youtube\.com|youtu\.be|facebook\.com|fb\.watch|fb\.com|tiktok\.com)[^\s]*)",
    re.I,
)

START_TEXT = (
    "👋✨ Salom men Izlovchibotman!\n\n"
    "💎 Mening xususiyatlarim bilan tanishing:\n\n"
    "• Qo'shiq matni, nomi yoki ijrochi ismi orqali musiqa topaman\n\n"
    "• Instagram, Youtube va Tik-Tokdan video va undagi musiqani yuklab beraman\n\n"
    "• Bundan tashqari men ovozli xabar, video va audiodagi musiqani to'liq shaklda topib beraman\n\n"
    "🚀 Qisqasi, izlash — mening ishim.\n\n"
    "👇 Video linkini yoki qo'shiq nomini yuboring!"
)

bot = Bot(BOT_TOKEN, default=DefaultBotProperties(parse_mode="HTML"))
dp = Dispatcher()
shazam = Shazam()
sem = asyncio.Semaphore(4)  # bir vaqtda 4 ta yuklash
CACHE: dict[str, str] = {}  # qisqa id -> url


def put(url: str) -> str:
    if len(CACHE) > 5000:
        CACHE.clear()
    key = uuid.uuid4().hex[:10]
    CACHE[key] = url
    return key


# ---------------- Majburiy obuna ----------------
async def is_subscribed(user_id: int) -> bool:
    try:
        m = await bot.get_chat_member(CHANNEL, user_id)
        return m.status not in ("left", "kicked")
    except Exception as e:
        log.error("Obunani tekshirib bo'lmadi (bot kanalda admin emasmi?): %s", e)
        return False


def sub_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="📢 Obuna bo'lish", url=CHANNEL_URL)],
            [InlineKeyboardButton(text="✅ Tekshirish", callback_data="check_sub")],
        ]
    )


SUB_TEXT = (
    "❌ Siz obuna bo'lmagansiz!\n\n"
    "Botdan foydalanish uchun avval kanalimizga obuna bo'ling, "
    "so'ng «Tekshirish» tugmasini bosing 👇"
)


class SubMiddleware(BaseMiddleware):
    async def __call__(self, handler, event, data):
        user = data.get("event_from_user")
        if user and not (isinstance(event, CallbackQuery) and event.data == "check_sub"):
            if not await is_subscribed(user.id):
                if isinstance(event, Message):
                    await event.answer(SUB_TEXT, reply_markup=sub_kb())
                elif isinstance(event, CallbackQuery):
                    await event.answer("❌ Siz obuna bo'lmagansiz!", show_alert=True)
                    await event.message.answer(SUB_TEXT, reply_markup=sub_kb())
                return
        return await handler(event, data)


dp.message.outer_middleware(SubMiddleware())
dp.callback_query.outer_middleware(SubMiddleware())


@dp.callback_query(F.data == "check_sub")
async def check_sub(call: CallbackQuery):
    if await is_subscribed(call.from_user.id):
        await call.message.delete()
        await call.message.answer(START_TEXT)
    else:
        await call.answer("❌ Siz hali obuna bo'lmagansiz!", show_alert=True)


# ---------------- Yuklash funksiyalari (sinxron) ----------------
def base_opts(out_dir: str) -> dict:
    o = {
        "outtmpl": f"{out_dir}/%(id)s.%(ext)s",
        "noplaylist": True,
        "quiet": True,
        "no_warnings": True,
        "concurrent_fragment_downloads": 8,
        "retries": 3,
    }
    if os.path.exists(COOKIES_FILE):
        o["cookiefile"] = COOKIES_FILE
    return o


def dl_video(url: str, out_dir: str):
    """1080p dan boshlab, 50MB dan oshsa pastroq sifatga tushadi."""
    path, info = None, None
    for h in (1080, 720, 480, 360):
        opts = base_opts(out_dir)
        opts.update(
            {
                "format": (
                    f"bestvideo[height<={h}][vcodec^=avc1]+bestaudio[ext=m4a]/"
                    f"bestvideo[height<={h}]+bestaudio/best[height<={h}]/best"
                ),
                "merge_output_format": "mp4",
            }
        )
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(url, download=True)
            p = Path(ydl.prepare_filename(info))
            if not p.exists():
                p = p.with_suffix(".mp4")
        path = p
        if path.exists() and path.stat().st_size <= MAX_SIZE:
            return path, info
        if path.exists():
            path.unlink()
        path = None
    return None, info


def dl_audio(target: str, out_dir: str):
    opts = base_opts(out_dir)
    opts.update(
        {
            "format": "bestaudio/best",
            "postprocessors": [
                {"key": "FFmpegExtractAudio", "preferredcodec": "mp3", "preferredquality": "192"}
            ],
        }
    )
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(target, download=True)
        if "entries" in info:
            info = info["entries"][0]
    path = Path(out_dir) / f"{info['id']}.mp3"
    return path, info


def yt_search(query: str, n: int = 8):
    opts = {"quiet": True, "no_warnings": True, "extract_flat": True}
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(f"ytsearch{n}:{query}", download=False)
    return info.get("entries", [])


async def trim_audio(src: str, dst: str, seconds: int = 25) -> str:
    """Shazam tezroq ishlashi uchun faqat boshidan bir necha soniyani olamiz."""
    proc = await asyncio.create_subprocess_exec(
        "ffmpeg", "-y", "-i", src, "-t", str(seconds), "-vn", "-ac", "1", "-ar", "44100", dst,
        stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL,
    )
    await proc.wait()
    return dst if os.path.exists(dst) else src


async def shazam_find(file_path: str, tmp: str):
    try:
        short = await trim_audio(file_path, os.path.join(tmp, "shazam.mp3"))
        res = await shazam.recognize(short)
        track = res.get("track")
        if track:
            return track.get("title"), track.get("subtitle")
    except Exception as e:
        log.warning("Shazam xato: %s", e)
    return None, None


async def send_full_song(msg: Message, title: str, artist: str, tmp: str):
    path, info = await asyncio.to_thread(dl_audio, f"ytsearch1:{artist} - {title}", tmp)
    await msg.answer_audio(
        FSInputFile(path),
        title=title,
        performer=artist,
        caption=f"🎵 <b>{html.escape(artist)} — {html.escape(title)}</b>\n\n🤖 @{(await bot.me()).username}",
    )


# ---------------- Handlerlar ----------------
@dp.message(CommandStart())
async def start(m: Message):
    await m.answer(START_TEXT)


@dp.message(F.text.regexp(URL_RE))
async def link_handler(m: Message):
    url = URL_RE.search(m.text).group(1)
    wait = await m.answer("⏳ Yuklanmoqda...")
    async with sem:
        with tempfile.TemporaryDirectory() as tmp:
            try:
                path, info = await asyncio.to_thread(dl_video, url, tmp)
                if not path:
                    await wait.edit_text("❌ Video juda katta (50MB dan oshdi) yoki yuklab bo'lmadi.")
                    return
                kb = InlineKeyboardMarkup(
                    inline_keyboard=[
                        [InlineKeyboardButton(text="🎵 Qo'shiqni yuklab olish", callback_data=f"song:{put(url)}")]
                    ]
                )
                await m.answer_video(
                    FSInputFile(path),
                    width=info.get("width"),
                    height=info.get("height"),
                    duration=int(info.get("duration") or 0) or None,
                    supports_streaming=True,
                    caption=f"🤖 @{(await bot.me()).username}",
                    reply_markup=kb,
                )
                await wait.delete()
            except Exception as e:
                log.exception(e)
                await wait.edit_text("❌ Videoni yuklab bo'lmadi. Linkni tekshirib qayta yuboring.")


@dp.callback_query(F.data.startswith("song:"))
async def song_cb(call: CallbackQuery):
    url = CACHE.get(call.data.split(":", 1)[1])
    if not url:
        return await call.answer("Eskirgan tugma, linkni qayta yuboring.", show_alert=True)
    await call.answer("🎵 Qo'shiq izlanmoqda...")
    wait = await call.message.answer("🔎 Qo'shiq topilmoqda...")
    async with sem:
        with tempfile.TemporaryDirectory() as tmp:
            try:
                path, info = await asyncio.to_thread(dl_audio, url, tmp)
                title, artist = await shazam_find(str(path), tmp)
                if title:
                    await send_full_song(call.message, title, artist, tmp)
                else:
                    await call.message.answer_audio(
                        FSInputFile(path),
                        title=info.get("title"),
                        caption="ℹ️ Shazam qo'shiqni aniqlay olmadi, videodagi audio yuborildi.",
                    )
                await wait.delete()
            except Exception as e:
                log.exception(e)
                await wait.edit_text("❌ Qo'shiqni topib bo'lmadi.")


@dp.message(F.voice | F.audio | F.video | F.video_note)
async def media_handler(m: Message):
    wait = await m.answer("🔎 Qo'shiq aniqlanmoqda...")
    media = m.voice or m.audio or m.video or m.video_note
    async with sem:
        with tempfile.TemporaryDirectory() as tmp:
            try:
                src = os.path.join(tmp, "in.bin")
                await bot.download(media, destination=src)  # 20MB gacha
                title, artist = await shazam_find(src, tmp)
                if not title:
                    return await wait.edit_text("😕 Qo'shiq topilmadi. Boshqa parcha yuboring.")
                await send_full_song(m, title, artist, tmp)
                await wait.delete()
            except Exception as e:
                log.exception(e)
                await wait.edit_text("❌ Xatolik. Fayl 20MB dan kichik bo'lishi kerak.")


@dp.message(F.text & ~F.text.startswith("/"))
async def search_handler(m: Message):
    wait = await m.answer("🔎 Izlanmoqda...")
    try:
        results = await asyncio.to_thread(yt_search, m.text)
        if not results:
            return await wait.edit_text("😕 Hech narsa topilmadi.")
        rows, lines = [], []
        for i, r in enumerate(results, 1):
            dur = int(r.get("duration") or 0)
            lines.append(f"{i}. {html.escape(r.get('title') or '')} — {dur // 60}:{dur % 60:02d}")
            rows.append([InlineKeyboardButton(text=str(i), callback_data=f"pick:{put(r['url'])}")])
        # raqam tugmalarini 4 tadan qatorga bo'lamiz
        flat = [b for row in rows for b in row]
        kb = InlineKeyboardMarkup(inline_keyboard=[flat[i:i + 4] for i in range(0, len(flat), 4)])
        await wait.edit_text("\n".join(lines) + "\n\n👇 Kerakli raqamni tanlang", reply_markup=kb)
    except Exception as e:
        log.exception(e)
        await wait.edit_text("❌ Qidiruvda xatolik.")


@dp.callback_query(F.data.startswith("pick:"))
async def pick_cb(call: CallbackQuery):
    url = CACHE.get(call.data.split(":", 1)[1])
    if not url:
        return await call.answer("Eskirgan tugma, qayta qidiring.", show_alert=True)
    await call.answer("⏳ Yuklanmoqda...")
    async with sem:
        with tempfile.TemporaryDirectory() as tmp:
            try:
                path, info = await asyncio.to_thread(dl_audio, url, tmp)
                await call.message.answer_audio(
                    FSInputFile(path),
                    title=info.get("title"),
                    performer=info.get("uploader"),
                    caption=f"🤖 @{(await bot.me()).username}",
                )
            except Exception as e:
                log.exception(e)
                await call.message.answer("❌ Qo'shiqni yuklab bo'lmadi.")


async def main():
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
